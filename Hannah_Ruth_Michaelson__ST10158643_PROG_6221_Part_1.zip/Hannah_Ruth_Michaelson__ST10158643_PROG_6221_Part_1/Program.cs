﻿using Hannah_Ruth_Michaelson__ST10158643_PROG_6221_Part_1.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hannah_Ruth_Michaelson__ST10158643_PROG_6221_Part_1
{

    internal class Program
    {
        
        static void Main(string[] args)
        {
         /// <summary>
         /// Local Recipe Class Object
         /// </summary>
            RecipeWorker obj = new RecipeWorker();
            obj.StartProg();
            

          
        }
    }
}//__---____---____---____---____---____---____---__.ooo END OF FILE ooo.__---____---____---____---____---____---____---__\\
